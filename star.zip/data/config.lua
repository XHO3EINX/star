do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "BanHammer",
    "Fun",
    "Msg-Checks",
    "Plugins",
    "Tools",
    "Write",
    "GroupManager"
  },
  info_text = "\9》MaTaDoR BoT v5.7\nAn advanced administration bot based on https://valtman.name/telegram-cli\n\n》https://github.com/BeyondTeam/BDReborn \n\n》Admins :\n》@alisaber313 ➣ Founder & Developer《\n》@JavadSudo ➣ Developer《\n》@Shaniloop ➣ Developer《\n\n》Special thanks to :\n》themargotrobbie\n》@Xamarin_Devloper\n\n》Our channel :\n》@themargotrobbie《\n",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    300131107,
    132622188,
    499637676
  }
}
return _
end